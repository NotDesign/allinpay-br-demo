// Explicit public allowlist. Private originals, diagnostics and source docs never enter Pages.
import {cp,mkdir,rm,writeFile,readFile,readdir} from 'node:fs/promises';
const root=new URL('../',import.meta.url),out=new URL('dist/',root);
await rm(out,{recursive:true,force:true});await mkdir(out,{recursive:true});
for(const file of ['index.html','styles.css','src'])await cp(new URL(file,root),new URL(file,out),{recursive:true});
for(const dir of ['vendor','fixtures'])await cp(new URL(`public/${dir}`,root),new URL(dir,out),{recursive:true});
await cp(new URL('public/vendor-manifest.json',root),new URL('vendor-manifest.json',out));
await writeFile(new URL('.nojekyll',out),'');
await writeFile(new URL('robots.txt',out),'User-agent: *\nDisallow: /\n');
const html=await readFile(new URL('index.html',out),'utf8');
if(/(?:src|href)="\/(?!\/)/.test(html))throw new Error('Root-relative path prevents project Pages deployment');
const files=await readdir(out);console.log('Built static site:',files.join(', '));
