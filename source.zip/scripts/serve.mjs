import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const port = Number(process.env.PORT || 8765);
const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.json':'application/json','.wasm':'application/wasm','.gz':'application/gzip','.png':'image/png','.jpg':'image/jpeg','.pdf':'application/pdf','.svg':'image/svg+xml','.bcmap':'application/octet-stream','.ttf':'font/ttf','.pfb':'application/octet-stream'};
export const csp = "default-src 'none'; script-src 'self' 'wasm-unsafe-eval'; worker-src 'self' blob:; style-src 'self'; img-src 'self' blob: data:; connect-src 'self'; font-src 'self' blob: data:; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'";
const server = http.createServer(async (req,res) => {
  res.setHeader('Content-Security-Policy',csp);
  res.setHeader('Cache-Control','no-store');
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
  if (!['GET','HEAD'].includes(req.method)) { res.writeHead(405); return res.end(); }
  if (!['127.0.0.1','localhost','[::1]'].includes((req.headers.host||'').replace(/:\d+$/,''))) { res.writeHead(403);return res.end(); }
  try {
    const url = new URL(req.url,'http://127.0.0.1');
    const name = decodeURIComponent(url.pathname);
    if (name.includes('..') || name.includes('\\') || name.includes('\0')) throw new Error();
    const relative = name==='/'?'index.html':name.replace(/^\//,'');
    const allowed = ['index.html','styles.css'].includes(relative) || /^(src|vendor|fixtures)\/[\w./-]+$/.test(relative);
    if(!allowed) throw new Error();
    const base = /^(vendor|fixtures)\//.test(relative) ? path.join(root,'public') : root;
    const data = await readFile(path.join(base,relative));
    res.writeHead(200,{'Content-Type':mime[path.extname(relative)]||'application/octet-stream'});
    res.end(req.method==='HEAD'?undefined:data);
  } catch { res.writeHead(404);res.end('Not found'); }
});
server.listen(port,'127.0.0.1',()=>console.log(`AllinPay BR Demo: http://127.0.0.1:${port} (local-only, no upload endpoint)`));
