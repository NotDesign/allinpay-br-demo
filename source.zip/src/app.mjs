import {loadDocument,recognizeDocument} from './engine.mjs';
import {FIELD_DEFS,parseBR,validateFields,toApplication} from './parser.mjs';
import {rotateCanvas} from './image-processing.mjs';
const $=id=>document.getElementById(id);
let doc=null,currentPage=null,result=null,controller=null,generation=0,previewRotation=0,busy=false,loadBusy=false;
const selected=new Set();
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const show=(id,visible)=>$(id).hidden=!visible;
function message(text=''){ $('message').textContent=text;show('message',!!text);}
function step(n){for(let i=1;i<=3;i++)$('step-'+i).className=i===n?'active':i<n?'done':'';}
function setBusy(value){busy=value;for(const id of ['page-select','scan','force-ocr','rotate','manual','sample-pdf','sample-image','file-input'])$(id).disabled=value;show('progress-area',value);updateApply();}
function updateApply(){ $('apply').disabled=busy||!result||!$('confirmed').checked||!FIELD_DEFS.some(f=>f.target&&selected.has(f.key)&&result.fields[f.key].value.trim());}
function clearResult(){result=null;selected.clear();$('fields').innerHTML='<div class="empty-state"><span>⌕</span><p>準備好後，辨識結果會顯示於此。</p></div>';$('raw-text').textContent='';$('warnings').replaceChildren();$('confirmed').checked=false;$('result-count').textContent='等候辨識';$('result-meta').textContent='系統會把可讀取的欄位列在這裡。';show('raw-details',false);show('review-actions',false);show('application-section',false);$('application-fields').replaceChildren();}
async function clearAll(){generation++;controller?.abort();controller=null;setBusy(false);loadBusy=false;if(currentPage){currentPage.canvas.width=1;currentPage.canvas.height=1;}currentPage=null;const previous=doc;doc=null;$('document-view').replaceChildren();clearResult();$('file-input').value='';$('file-name').textContent='';$('file-meta').textContent='';show('workbench',false);show('upload-section',true);step(1);message();try{await previous?.destroy();}catch{} }
function renderPreview(){ $('document-view').replaceChildren();if(currentPage){const preview=rotateCanvas(currentPage.canvas,previewRotation);preview.setAttribute('role','img');preview.setAttribute('aria-label','所選 BR 第 '+$('page-select').value+' 頁原件預覽');$('document-view').append(preview);} }
async function renderPage(number){const token=generation,source=doc;clearResult();previewRotation=0;if(currentPage)currentPage.canvas.width=1;currentPage=null;const rendered=await source.render(number);if(token!==generation||source!==doc){rendered.canvas.width=1;return;}currentPage=rendered;renderPreview();}
async function accept(file){if(busy||loadBusy)return;await clearAll();loadBusy=true;const token=++generation;message('正在本機開啟文件…');try{
 const opened=await loadDocument(file);if(token!==generation){await opened.destroy();return;}doc=opened;
 $('file-name').textContent=doc.name;$('file-meta').textContent=`${(doc.size/1024/1024).toFixed(2)} MB · ${doc.pages} 頁 · 僅本頁暫存`;
 $('page-select').innerHTML=Array.from({length:doc.pages},(_,i)=>`<option value="${i+1}">${i+1} / ${doc.pages}</option>`).join('');
 await renderPage(1);if(token!==generation)return;show('upload-section',false);show('workbench',true);step(2);message();loadBusy=false;
 if(doc.pages===1)await scan();else message('這份 PDF 有多頁。請選擇 BR 所在的頁面，再按「辨識這一頁」。每次只辨識一頁。');
 }catch(error){if(token===generation){message(error.message||'無法開啟文件。');await doc?.destroy();doc=null;}}finally{if(token===generation)loadBusy=false;}}
async function scan(forceOCR=false){if(!currentPage||busy||loadBusy)return;clearResult();message();setBusy(true);const token=++generation;controller=new AbortController();const signal=controller.signal;
 let timeout=false;const timer=setTimeout(()=>{timeout=true;controller?.abort();if(token===generation){generation++;setBusy(false);message('辨識超過 120 秒，已停止。請選擇較清晰或較小的文件，或改用手動填寫。');}},120000);
 try {const recognized=await recognizeDocument({canvas:currentPage.canvas,text:currentPage.text,page:+$('page-select').value,forceOCR,signal,onProgress:({progress,label})=>{if(token===generation){$('progress').value=progress;$('progress-label').textContent=label;}}});
 if(token!==generation||signal.aborted)return;result=recognized;renderResults();
 }catch(error){if(token===generation)message(signal.aborted?(timeout?'辨識逾時。':'已取消辨識，可重新辨識或改用手動填寫。'):'本機辨識未完成。請重試，或改用較清晰的檔案；也可使用手動填寫。');}
 finally{clearTimeout(timer);if(token===generation){controller=null;setBusy(false);}}
}
function renderResults(){
 selected.clear();for(const f of FIELD_DEFS)if(result.fields[f.key].value&&f.target&&result.recognized&&result.fields[f.key].autoSelect!==false)selected.add(f.key);
 $('result-count').textContent=`${FIELD_DEFS.filter(f=>result.fields[f.key].value).length} / ${FIELD_DEFS.length} 欄位有候選值`;
 $('result-meta').textContent=result.method==='pdf-text'?'來源：PDF 文字層 · 所有欄位均需核對':result.method==='manual'?'手動填寫模式 · 沒有文件來源':`來源：本機圖片 OCR${result.recovered?'（低解析度分區辨識）':''} · 轉向 ${result.rotation}° · 歪斜校正 ${result.skew}° · 用時 ${(result.elapsed/1000).toFixed(1)} 秒`;
 $('warnings').innerHTML=result.warnings.map(w=>`<p>${escape(w)}</p>`).join('');
 $('fields').innerHTML=FIELD_DEFS.map(f=>{const data=result.fields[f.key];return `<div class="review-field ${data.value?'':'missing'}" data-key="${f.key}"><div class="field-label">${f.target?`<input type="checkbox" class="include-field" data-key="${f.key}" id="include-${f.key}" aria-label="帶入${f.label}" ${selected.has(f.key)?'checked':''}>`:''}<label for="value-${f.key}">${f.label}</label><span class="field-state">${f.target?(data.warning?'需特別核對':data.lowResolution?'低畫質 · 待核對':data.value?'待核對':'未辨識'):'只供核對'}</span></div>${/Address|nature/.test(f.key)?`<textarea id="value-${f.key}" data-key="${f.key}" class="candidate" autocomplete="off" spellcheck="false">${escape(data.value)}</textarea>`:`<input id="value-${f.key}" data-key="${f.key}" class="candidate" value="${escape(data.value)}" autocomplete="off" spellcheck="false" placeholder="${f.key.endsWith('Date')?'YYYY-MM-DD':'未找到，可手動補充'}">`}${data.source?`<details class="source-line"><summary>查看來源文字 · 第 ${data.page} 頁</summary>${escape(data.source)}</details>`:''}${data.warning?`<p class="field-attention">${escape(data.warning)}</p>`:''}${data.alternatives?.length?`<p class="field-attention">辨識候選：${data.alternatives.map(escape).join(' / ')}。請參照原件輸入。</p>`:''}${f.key==='startDate'?'<p class="hint">僅代表本張證書生效日期，不帶入公司成立日期或經營年限。</p>':''}${f.key==='brNumber'?'<p class="hint">保留原有 8 位號碼及 3 位分支碼；不自動補 0。</p>':''}<p class="field-error" id="error-${f.key}" role="alert"></p></div>`;}).join('');
 $('raw-text').textContent=result.rawText;show('raw-details',!!result.rawText);$('raw-details').open=false;show('review-actions',true);$('confirmed').checked=false;updateApply();
}
function apply(){
 if(!result||!$('confirmed').checked)return;
 const checkedFields=Object.fromEntries(Object.entries(result.fields).filter(([k])=>selected.has(k)||k==='startDate'));
 const errors=validateFields(checkedFields);for(const f of FIELD_DEFS){$('error-'+f.key).textContent=errors[f.key]||'';$('value-'+f.key).setAttribute('aria-invalid',errors[f.key]?'true':'false');}
 if(Object.keys(errors).length){$('error-'+Object.keys(errors)[0]).scrollIntoView({behavior:'smooth',block:'center'});return;}
 const data=toApplication(result.fields,selected);const labels={merchantName:'公司中文名稱',merchantEnglishName:'公司英文名稱',registerCertNo:'BR 號碼及分支碼',registerCertName:'註冊證書名稱',registerCertType:'註冊證書類型',addrStreet:'業務地址（中文）',addrStreetEn:'業務地址（英文）',merchantProfile:'業務性質／客戶簡介',legalStatus:'法律地位',registerCertPeriod:'BR 屆滿日期'};
 $('application-fields').innerHTML=Object.entries(labels).map(([key,label])=>`<label>${label}<input data-target="${key}" value="${escape(data[key]||'')}" placeholder="尚未填寫" autocomplete="off" spellcheck="false"><small>${data[key]?'由本次核對結果帶入':'未取得，待補充'}</small></label>`).join('');
 $('application-note').textContent=`已帶入 ${Object.keys(data).length} 個申請欄位。這是本頁表單預覽，沒有儲存或提交至正式系統。地址保留 BR 原文，地區拆分留待後續確認。`;
 show('workbench',false);show('application-section',true);message();step(3);$('application-section').scrollIntoView({behavior:'smooth',block:'start'});
}
$('file-input').addEventListener('change',event=>{const file=event.target.files[0];if(file)void accept(file);});
$('dropzone').addEventListener('dragover',event=>{event.preventDefault();$('dropzone').classList.add('dragover');});
$('dropzone').addEventListener('dragleave',()=>$('dropzone').classList.remove('dragover'));
$('dropzone').addEventListener('drop',event=>{event.preventDefault();$('dropzone').classList.remove('dragover');if(event.dataTransfer.files.length!==1){message('請一次選擇一份 BR 文件。');return;}void accept(event.dataTransfer.files[0]);});
for(const [id,url,type]of [['sample-pdf','./fixtures/sample-br.pdf','application/pdf'],['sample-image','./fixtures/sample-br-skew.png','image/png']])$(id).addEventListener('click',async()=>{try{const response=await fetch(url);if(!response.ok)throw new Error();await accept(new File([await response.blob()],url.split('/').pop(),{type}));}catch{message('測試檔案尚未準備好。');}});
$('page-select').addEventListener('change',async()=>{if(busy||loadBusy)return;loadBusy=true;const token=++generation;$('page-select').disabled=true;try{await renderPage(+$('page-select').value);if(token===generation)message('已切換頁面。請確認原件後按「辨識這一頁」。');}catch{message('此頁無法預覽，請使用另一份文件。');}finally{if(token===generation){loadBusy=false;$('page-select').disabled=false;}}});
$('scan').addEventListener('click',()=>void scan());$('force-ocr').addEventListener('click',()=>void scan(true));
$('rotate').addEventListener('click',()=>{previewRotation=(previewRotation+90)%360;renderPreview();});
$('clear').addEventListener('click',()=>void clearAll());$('restart').addEventListener('click',()=>void clearAll());
$('cancel').addEventListener('click',()=>{generation++;controller?.abort();controller=null;setBusy(false);message('已取消辨識。原件留在本頁，可重新辨識，或清除文件與資料。');});
$('fields').addEventListener('input',event=>{const element=event.target;if(element.classList.contains('candidate')){result.fields[element.dataset.key].value=element.value;result.fields[element.dataset.key].edited=true;$('confirmed').checked=false;updateApply();}});
$('fields').addEventListener('change',event=>{const element=event.target;if(element.classList.contains('include-field')){if(element.checked)selected.add(element.dataset.key);else selected.delete(element.dataset.key);$('confirmed').checked=false;updateApply();}});
$('confirmed').addEventListener('change',updateApply);$('apply').addEventListener('click',apply);
$('back').addEventListener('click',()=>{show('application-section',false);show('workbench',true);step(2);});
// Manual mode shares the same validation and explicit review gate.
$('manual').addEventListener('click',async()=>{await clearAll();result=parseBR('',{method:'manual'});result.warnings=[];result.recognized=false;show('upload-section',false);show('workbench',true);$('file-name').textContent='手動填寫';$('file-meta').textContent='沒有選擇文件';renderResults();step(2);});
addEventListener('pagehide',()=>{generation++;controller?.abort();void doc?.destroy();if(currentPage)currentPage.canvas.width=1;result=null;doc=null;currentPage=null;});
